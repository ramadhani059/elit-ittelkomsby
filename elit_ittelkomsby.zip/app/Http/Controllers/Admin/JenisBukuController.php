<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\M_Buku;
use App\Models\R_File_Place;
use App\Models\R_Jenis_Buku;
use App\Models\R_Koleksi_Buku;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class JenisBukuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $pageTitle = 'Jenis Buku | ELIT ITTelkom Surabaya';

        $jenisbuku = R_Jenis_Buku::all();

        return view('admin/jenisbuku/index', [
            'pageTitle' => $pageTitle,
            'jenisbuku' => $jenisbuku
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $pageTitle = 'Tambah Jenis Buku | Dashboard';

        $koleksibuku = R_Koleksi_Buku::all();

        return view('admin.jenisbuku.add', compact('pageTitle', 'koleksibuku'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $jenisbuku = new R_Jenis_Buku;
        $fileplace = new R_File_Place;

        $target1 = count(collect($request->identitas_buku));
        $target2 = count(collect($request->nama_file));
        $target3 = count(collect($request->fullfile));

        $jenisbuku->id_koleksi = $request->koleksibuku;
        $jenisbuku->kode_jenis_buku = $request->kodejenisbuku;
        $jenisbuku->nama = $request->namajenisbuku;

        $jenisbuku->save();

        if ($request->identitas_buku[0] != null){
            for ($x=0; $x<$target1; $x++){
                $checkbox[] = array(
                    'id_jenisbuku' => $jenisbuku->id,
                    'name' => $request->identitas_buku[$x],
                    'note' => null,
                    'type' => 'text',
                );
            }
            DB::table('r__file__places')->insert($checkbox);
        }

        if ($request->fullfile[0] != null){
            for ($x=0; $x<$target3; $x++){
                $fullfile[] = array(
                    'id_jenisbuku' => $jenisbuku->id,
                    'name' => $request->fullfile[$x],
                    'note' => null,
                    'type' => 'fullfile',
                );
            }
            DB::table('r__file__places')->insert($fullfile);
        }

        if ($request->nama_file[0] != null){
            for ($i=0; $i<$target2; $i++){
                $data[] = array(
                    'id_jenisbuku' => $jenisbuku->id,
                    'name' => $request->nama_file[$i],
                    'note' => $request->note_file[$i],
                    'type' => 'pdf',
                );
            }
            DB::table('r__file__places')->insert($data);
        }

        return redirect()->route('jenis-buku.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $fileplace = R_File_Place::where('id_jenisbuku',$id);
        $jenisbuku = R_Jenis_Buku::find($id);

        $fileplace->delete();
        $jenisbuku->delete();

        return redirect()->route('jenis-buku.index');
    }
}
