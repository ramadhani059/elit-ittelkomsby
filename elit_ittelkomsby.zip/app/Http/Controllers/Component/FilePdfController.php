<?php

namespace App\Http\Controllers\Component;

use App\Http\Controllers\Controller;
use App\Models\M_Buku;
use Illuminate\Http\Request;

class FilePdfController extends Controller
{
    public function getPdfViews($id){
        $catalog = M_Buku::find($id);

        foreach ($catalog->file as $filebuku) {
            if ($filebuku->file_place->name == 'File' && $filebuku->file_place->type == 'fullfile') {
                $path = public_path('storage/buku/26/B4mA7Ni5u15L4tSkV507sFNOKZkexFJYu9o1i28i.pdf');
            }
        }

        return response()->file($path);
    }
}
