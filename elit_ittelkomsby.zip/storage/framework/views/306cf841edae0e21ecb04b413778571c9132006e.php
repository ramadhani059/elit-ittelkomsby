<?php $__env->startSection('css'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@ttskch/select2-bootstrap4-theme@x.x.x/dist/select2-bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-xxl flex-grow-1 container-p-y">

    <div
      class="bs-toast toast toast-placement-ex m-2 bg-danger top-0 end-0"
      role="alert"
      aria-live="assertive"
      aria-atomic="true"
      data-delay="2000"
      id="custom-target"
    >
      <div class="toast-header">
        <i class="bx bx-bell me-2"></i>
        <div class="me-auto fw-semibold">Information</div>
        <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>
      <div class="toast-body">Kode Buku yang Anda Masukkan Belum Terdaftar</div>
    </div>

    <!-- Basic with Icons -->
    <div class="col-xxl">
        <div class="card mb-4">
          <div class="card-body">
            <form action="<?php echo e(route('akuisisi-buku.store')); ?>" method="POST" enctype="multipart/form-data" id="katalogForm">
              <?php echo csrf_field(); ?>
              <div class="row">
                <div class="col-sm-12 mb-3">
                    <label for="defaultFormControlInput" class="form-label">
                        Jenis Buku
                    </label>
                    <div class="input-group">
                        <span class="input-group-text" id="basic-addon11">
                            <i class="bx bxs-book-alt"></i>
                        </span>
                        <select class="form-select jenis_buku <?php $__errorArgs = ['jenis_buku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jenis_buku" name="jenis_buku">
                            <option value=""></option>
                            <?php $__currentLoopData = $jenisbuku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis_buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($jenis_buku->id); ?>"><?php echo e($jenis_buku->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div id="defaultFormControlHelp" class="form-text text-danger">
                        <span class="errorTxt" id="jenis_buku-errorMsg"></span>
                    </div>
                </div>
              </div>
              <?php $__currentLoopData = $jenisbuku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis_buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="some" id="some_<?php echo e($jenis_buku->id); ?>" style="display: none;">
                    <div class="row">
                        <div class="col-sm-12 mb-3">
                            <label for="defaultFormControlInput" class="form-label">
                                Kode Buku
                            </label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon11">
                                    <i class="bx bx-hash"></i>
                                </span>
                                <input
                                    id="kode_buku_<?php echo e($jenis_buku->id); ?>"
                                    type="text"
                                    class="form-control <?php $__errorArgs = ['kode_buku_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="kode_buku_<?php echo e($jenis_buku->id); ?>"
                                    placeholder="01.04.2238"
                                    aria-describedby="basic-addon13"
                                    required
                                    autofocus
                                />
                                <button
                                    class="btn btn-outline-primary"
                                    id="checkkodebuku_<?php echo e($jenis_buku->id); ?>"
                                    data-bs-toggle="tooltip"
                                    data-bs-offset="0,4"
                                    data-bs-placement="left"
                                    data-bs-html="true"
                                    title="<span>Check Kode Buku</span>"
                                >
                                    <i class="bx bx-search-alt-2"></i>
                                </button>
                            </div>
                            <div id="defaultFormControlHelp" class="form-text text-danger">
                                <span class="errorTxt" id="kode_buku_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                            </div>
                        </div>
                        <?php $__currentLoopData = $jenis_buku->file_place; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($field->name == 'ISBN' && $field->type == 'text'): ?>
                                <div class="col-sm-6 mb-3">
                                    <label for="defaultFormControlInput" class="form-label">
                                        ISBN
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon11">
                                            <i class="bx bx-hash"></i>
                                        </span>
                                        <input
                                            id="isbn_<?php echo e($jenis_buku->id); ?>"
                                            type="text"
                                            class="form-control <?php $__errorArgs = ['isbn_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="isbn_<?php echo e($jenis_buku->id); ?>"
                                            placeholder="Enter ISBN"
                                            aria-describedby="basic-addon13"
                                            required
                                            autofocus
                                        />
                                    </div>
                                    <div id="defaultFormControlHelp" class="form-text text-danger">
                                        <span class="errorTxt" id="isbn_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if($field->name == 'Lokasi Buku' && $field->type == 'text'): ?>
                                <div class="col-sm-6 mb-3">
                                    <label for="defaultFormControlInput" class="form-label">
                                        Lokasi Buku
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon11">
                                            <i class="bx bxs-bar-chart-alt-2"></i>
                                        </span>
                                        <input
                                            id="lokasi_buku_<?php echo e($jenis_buku->id); ?>"
                                            type="text"
                                            class="form-control <?php $__errorArgs = ['lokasi_buku_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="lokasi_buku_<?php echo e($jenis_buku->id); ?>"
                                            placeholder="R. X.XX"
                                            aria-describedby="basic-addon13"
                                            required
                                            autofocus
                                        />
                                    </div>
                                    <div id="defaultFormControlHelp" class="form-text text-danger">
                                        <span class="errorTxt" id="lokasi_buku_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-12 mb-3">
                            <label for="defaultFormControlInput" class="form-label">
                                Judul Buku
                            </label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon11">
                                    <i class="bx bxs-book-alt"></i>
                                </span>
                                <input
                                    id="judul_buku_<?php echo e($jenis_buku->id); ?>"
                                    type="text"
                                    class="form-control <?php $__errorArgs = ['judul_buku_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="judul_buku_<?php echo e($jenis_buku->id); ?>"
                                    placeholder="Enter Your Book Title "
                                    aria-describedby="basic-addon13"
                                    required
                                    autofocus
                                />
                            </div>
                            <div id="defaultFormControlHelp" class="form-text text-danger">
                                <span class="errorTxt" id="judul_buku_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                            </div>
                        </div>
                        <?php $__currentLoopData = $jenis_buku->file_place; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($field->name == 'Judul Buku Inggris' && $field->type == 'text'): ?>
                                <div class="col-sm-12 mb-3">
                                    <label for="defaultFormControlInput" class="form-label">
                                        Judul Buku (Bahasa Inggris)
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon11">
                                            <i class="bx bxs-book-alt"></i>
                                        </span>
                                        <input
                                            id="judul_buku_inggris_<?php echo e($jenis_buku->id); ?>"
                                            type="text"
                                            class="form-control <?php $__errorArgs = ['judul_buku_inggris_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="judul_buku_inggris_<?php echo e($jenis_buku->id); ?>"
                                            placeholder="Enter Your Book Title in English Language "
                                            aria-describedby="basic-addon13"
                                            required
                                            autofocus
                                        />
                                    </div>
                                    <div id="defaultFormControlHelp" class="form-text text-danger">
                                        <span class="errorTxt" id="judul_buku_inggris_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if($field->name == 'Anak Judul' && $field->type == 'text'): ?>
                                <div class="col-sm-6 mb-3">
                                    <label for="defaultFormControlInput" class="form-label">
                                        Anak Judul
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon11">
                                            <i class="bx bxs-book-alt"></i>
                                        </span>
                                        <input
                                            id="anak_judul_<?php echo e($jenis_buku->id); ?>"
                                            type="text"
                                            class="form-control <?php $__errorArgs = ['anak_judul_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="anak_judul_<?php echo e($jenis_buku->id); ?>"
                                            placeholder="Enter Your Book Title "
                                            aria-describedby="basic-addon13"
                                            required
                                            autofocus
                                        />
                                    </div>
                                    <div id="defaultFormControlHelp" class="form-text text-danger">
                                        <span class="errorTxt" id="anak_judul_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if($field->name == 'Edisi' && $field->type == 'text'): ?>
                                <div class="col-sm-6 mb-3">
                                    <label for="defaultFormControlInput" class="form-label">
                                        Edisi
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon11">
                                            <i class="bx bxs-book-alt"></i>
                                        </span>
                                        <input
                                            id="edisi_buku_<?php echo e($jenis_buku->id); ?>"
                                            type="text"
                                            class="form-control <?php $__errorArgs = ['edisi_buku_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="edisi_buku_<?php echo e($jenis_buku->id); ?>"
                                            placeholder="Enter Your Book Edition "
                                            aria-describedby="basic-addon13"
                                        />
                                    </div>
                                    <div id="defaultFormControlHelp" class="form-text text-danger">
                                        <span class="errorTxt" id="edisi_buku_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 mb-3">
                            <label for="defaultFormControlInput" class="form-label">
                                Jenis Pengadaan
                            </label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon11">
                                    <i class="bx bxs-book-alt"></i>
                                </span>
                                <select class="form-select jenis_pengadaan <?php $__errorArgs = ['jenis_pengadaan_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jenis_pengadaan_<?php echo e($jenis_buku->id); ?>" name="jenis_pengadaan_<?php echo e($jenis_buku->id); ?>">
                                    <option value=""></option>
                                    <option value="pembelian">Pembelian</option>
                                    <option value="hibah/donasi">Hibah/Donasi</option>
                                    <option value="repository">Repository</option>

                                </select>
                            </div>
                            <div id="defaultFormControlHelp" class="form-text text-danger">
                                <span class="errorTxt" id="jenis_pengadaan_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                            </div>
                        </div>
                        <div class="col-sm-6 mb-3">
                            <label for="defaultFormControlInput" class="form-label">
                                Status Pengadaan
                            </label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon11">
                                    <i class="bx bxs-check-circle"></i>
                                </span>
                                <select class="form-select status_pengadaan <?php $__errorArgs = ['status_pengadaan_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status_pengadaan_<?php echo e($jenis_buku->id); ?>" name="status_pengadaan_<?php echo e($jenis_buku->id); ?>">
                                    <option value=""></option>
                                    <option value="dapat dipinjam">Dapat Dipinjam</option>
                                    <option value="tidak dapat dipinjam">Tidak Dapat Dipinjam</option>
                                </select>
                            </div>
                            <div id="defaultFormControlHelp" class="form-text text-danger">
                                <span class="errorTxt" id="status_pengadaan_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                            </div>
                        </div>
                        <?php $__currentLoopData = $jenis_buku->file_place; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($field->name == 'Ilustrasi' && $field->type == 'text'): ?>
                                <div class="col-sm-6 mb-3">
                                    <label for="defaultFormControlInput" class="form-label">
                                        Ilustrasi
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon11">
                                            <i class="bx bxs-book-alt"></i>
                                        </span>
                                        <input
                                            id="ilustrasi_<?php echo e($jenis_buku->id); ?>"
                                            type="text"
                                            class="form-control <?php $__errorArgs = ['ilustrasi_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="ilustrasi_<?php echo e($jenis_buku->id); ?>"
                                            placeholder="Enter Your Book Illustration "
                                            aria-describedby="basic-addon13"
                                        />
                                    </div>
                                    <div id="defaultFormControlHelp" class="form-text text-danger">
                                        <span class="errorTxt" id="ilustrasi_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if($field->name == 'Dimensi Buku' && $field->type == 'text'): ?>
                                <div class="col-sm-6 mb-3">
                                    <label for="defaultFormControlInput" class="form-label">
                                        Dimensi Buku
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon11">
                                            <i class="bx bxs-book-alt"></i>
                                        </span>
                                        <input
                                            id="dimensi_<?php echo e($jenis_buku->id); ?>"
                                            type="text"
                                            class="form-control <?php $__errorArgs = ['dimensi_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="dimensi_<?php echo e($jenis_buku->id); ?>"
                                            placeholder="Enter Your Book Dimension "
                                            aria-describedby="basic-addon13"
                                        />
                                    </div>
                                    <div id="defaultFormControlHelp" class="form-text text-danger">
                                        <span class="errorTxt" id="dimensi_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if($field->name == 'Program Studi' && $field->type == 'text'): ?>
                                <div class="col-sm-6 mb-3">
                                    <label for="defaultFormControlInput" class="form-label">
                                        Fakultas
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon11">
                                            <i class="bx bxs-graduation"></i>
                                        </span>
                                        <select class="form-select fakultas <?php $__errorArgs = ['fakultas_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="fakultas_<?php echo e($jenis_buku->id); ?>" name="fakultas_<?php echo e($jenis_buku->id); ?>">
                                            <option value=""></option>
                                            <?php $__currentLoopData = $fakultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fakultas_itts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($fakultas_itts->id); ?>"><?php echo e($fakultas_itts->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div id="defaultFormControlHelp" class="form-text text-danger">
                                        <span class="errorTxt" id="fakultas_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                                    </div>
                                </div>
                                <div class="col-sm-6 mb-3">
                                    <label for="defaultFormControlInput" class="form-label">
                                        Program Studi
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon11">
                                            <i class="bx bxs-graduation"></i>
                                        </span>
                                        <select class="form-select prodi <?php $__errorArgs = ['prodi_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="prodi_<?php echo e($jenis_buku->id); ?>" name="prodi_<?php echo e($jenis_buku->id); ?>">
                                            <option value=""></option>
                                            <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($jurusan->id); ?>"><?php echo e($jurusan->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div id="defaultFormControlHelp" class="form-text text-danger">
                                        <span class="errorTxt" id="prodi_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 mb-3">
                            <label for="defaultFormControlInput" class="form-label">
                                Jumlah Eksemplar
                            </label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon11">
                                    <i class="bx bxs-book-alt"></i>
                                </span>
                                <input
                                    id="jumlah_eksemplar_<?php echo e($jenis_buku->id); ?>"
                                    type="text"
                                    class="form-control <?php $__errorArgs = ['jumlah_eksemplar_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="jumlah_eksemplar_<?php echo e($jenis_buku->id); ?>"
                                    placeholder="0 Book"
                                    aria-describedby="basic-addon13"
                                    required
                                    autofocus
                                />
                            </div>
                            <div id="defaultFormControlHelp" class="form-text text-danger">
                                <span class="errorTxt" id="jumlah_eksemplar_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                            </div>
                        </div>
                        <div class="col-sm-3 mb-3">
                            <label for="defaultFormControlInput" class="form-label">
                                Kota Terbit
                            </label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon11">
                                    <i class="bx bxs-buildings"></i>
                                </span>
                                <input
                                    id="kota_terbit_<?php echo e($jenis_buku->id); ?>"
                                    type="text"
                                    class="form-control <?php $__errorArgs = ['kota_terbit_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="kota_terbit_<?php echo e($jenis_buku->id); ?>"
                                    placeholder="Surabaya"
                                    aria-describedby="basic-addon13"
                                    required
                                    autofocus
                                />
                            </div>
                            <div id="defaultFormControlHelp" class="form-text text-danger">
                                <span class="errorTxt" id="kota_terbit_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                            </div>
                        </div>
                        <div class="col-sm-3 mb-3">
                            <label for="defaultFormControlInput" class="form-label">
                                Tahun Terbit
                            </label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon11">
                                    <i class="bx bxs-calendar"></i>
                                </span>
                                <input
                                    id="tahun_terbit_<?php echo e($jenis_buku->id); ?>"
                                    type="text"
                                    class="form-control <?php $__errorArgs = ['tahun_terbit_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="tahun_terbit_<?php echo e($jenis_buku->id); ?>"
                                    placeholder="20XX"
                                    aria-describedby="basic-addon13"
                                    required
                                    autofocus
                                />
                            </div>
                            <div id="defaultFormControlHelp" class="form-text text-danger">
                                <span class="errorTxt" id="tahun_terbit_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                            </div>
                        </div>
                    </div>
                    <div class="subjek_wrapper_<?php echo e($jenis_buku->id); ?>">
                    </div>
                    <div class="pengarang_wrapper_<?php echo e($jenis_buku->id); ?>">
                    </div>
                    <?php $__currentLoopData = $jenis_buku->file_place; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($field->name == 'Pembimbing' && $field->type == 'text'): ?>
                            <div class="pembimbing_wrapper_<?php echo e($jenis_buku->id); ?>">
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <?php $__currentLoopData = $jenis_buku->file_place; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($field->name == 'Penyunting' && $field->type == 'text'): ?>
                                <div class="col-sm-6 mb-3">
                                    <label for="defaultFormControlInput" class="form-label">
                                        Nama Penyunting
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon11">
                                            <i class="bx bxs-user"></i>
                                        </span>
                                        <input
                                            id="penyunting_<?php echo e($jenis_buku->id); ?>"
                                            type="text"
                                            class="form-control <?php $__errorArgs = ['penyunting_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="penyunting_<?php echo e($jenis_buku->id); ?>"
                                            placeholder="Enter An Editor"
                                            aria-describedby="basic-addon13"
                                        />
                                    </div>
                                    <div id="defaultFormControlHelp" class="form-text text-danger">
                                        <span class="errorTxt" id="penyunting_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if($field->name == 'Penerjemah' && $field->type == 'text'): ?>
                                <div class="col-sm-6 mb-3">
                                    <label for="defaultFormControlInput" class="form-label">
                                        Nama Penerjemah
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon11">
                                            <i class="bx bxs-user"></i>
                                        </span>
                                        <input
                                            id="penerjemah_<?php echo e($jenis_buku->id); ?>"
                                            type="text"
                                            class="form-control <?php $__errorArgs = ['penerjemah_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="penerjemah_<?php echo e($jenis_buku->id); ?>"
                                            placeholder="Enter A Translator"
                                            aria-describedby="basic-addon13"
                                        />
                                    </div>
                                    <div id="defaultFormControlHelp" class="form-text text-danger">
                                        <span class="errorTxt" id="penerjemah_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if($field->name == 'Penerbit' && $field->type == 'text'): ?>
                                <div class="col-sm-6 mb-3">
                                    <label for="defaultFormControlInput" class="form-label">
                                        Nama Penerbit
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon11">
                                            <i class="bx bxs-user"></i>
                                        </span>
                                        <input
                                            id="penerbit_<?php echo e($jenis_buku->id); ?>"
                                            type="text"
                                            class="form-control <?php $__errorArgs = ['penerbit_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="penerbit_<?php echo e($jenis_buku->id); ?>"
                                            placeholder="Enter A Publisher"
                                            aria-describedby="basic-addon13"
                                            required
                                            autofocus
                                        />
                                    </div>
                                    <div id="defaultFormControlHelp" class="form-text text-danger">
                                        <span class="errorTxt" id="penerbit_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 mb-3">
                            <label for="defaultFormControlInput" class="form-label">
                                Cover Buku (PNG/JPG)
                            </label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon11">
                                    <i class="bx bxs-file-image"></i>
                                </span>
                                <input class="form-control" type="file" id="filecover_<?php echo e($jenis_buku->id); ?>" name="filecover_<?php echo e($jenis_buku->id); ?>" />
                            </div>
                            <div id="defaultFormControlHelp" class="form-text text-danger">
                                <span class="errorTxt" id="filecover_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                            </div>
                        </div>
                        <?php $__currentLoopData = $jenis_buku->file_place; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($field->name == 'File' && $field->type == 'fullfile'): ?>
                                <div class="col-sm-6 mb-3">
                                    <label for="defaultFormControlInput" class="form-label">
                                        Full File (PDF) / E-Book
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon11">
                                            <i class="bx bxs-file-pdf"></i>
                                        </span>
                                        <input class="form-control" type="file" id="fullfile_<?php echo e($field->id); ?>_<?php echo e($jenis_buku->id); ?>" name="fullfile_<?php echo e($field->id); ?>_<?php echo e($jenis_buku->id); ?>" />
                                    </div>
                                    <div id="defaultFormControlHelp" class="form-text text-danger">
                                        <span class="errorTxt" id="fullfile_<?php echo e($field->id); ?>_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 mb-3">
                            <label for="defaultFormControlInput" class="form-label">
                                Sirkulasi
                            </label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon11">
                                    <i class="bx bxs-book-alt"></i>
                                </span>
                                <select class="form-select sirkulasi <?php $__errorArgs = ['sirkulasi_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="sirkulasi_<?php echo e($jenis_buku->id); ?>" name="sirkulasi_<?php echo e($jenis_buku->id); ?>">
                                    <option value=""></option>
                                    <?php $__currentLoopData = $sirkulasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sirkulasibuku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($sirkulasibuku->id); ?>"><?php echo e($sirkulasibuku->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div id="defaultFormControlHelp" class="form-text text-danger">
                                <span class="errorTxt" id="sirkulasi_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                            </div>
                        </div>
                        <div class="col-sm-3 mb-3">
                            <label for="defaultFormControlInput" class="form-label">
                                Status
                            </label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon11">
                                    <i class="bx bxs-check-circle"></i>
                                </span>
                                <select class="form-select status <?php $__errorArgs = ['status_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status_<?php echo e($jenis_buku->id); ?>" name="status_<?php echo e($jenis_buku->id); ?>">
                                    <option value=""></option>
                                    <option value=0>Non Active</option>
                                    <option value=1>Active</option>
                                </select>
                            </div>
                            <div id="defaultFormControlHelp" class="form-text text-danger">
                                <span class="errorTxt" id="status_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                            </div>
                        </div>
                        <div class="col-sm-3 mb-3">
                            <label for="defaultFormControlInput" class="form-label">
                                Role Download
                            </label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon11">
                                    <i class="bx bxs-download"></i>
                                </span>
                                <select class="form-select role_download <?php $__errorArgs = ['role_download_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="role_download_<?php echo e($jenis_buku->id); ?>" name="role_download_<?php echo e($jenis_buku->id); ?>">
                                    <option value=""></option>
                                    <option value=0>Tidak Bisa Didownload</option>
                                    <option value=1>Bisa Didownload</option>
                                </select>
                            </div>
                            <div id="defaultFormControlHelp" class="form-text text-danger">
                                <span class="errorTxt" id="role_download_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                            </div>
                        </div>
                        <div class="col-sm-12 mb-3">
                            <label for="defaultFormControlInput" class="form-label">
                                Abstrak/Ringkasan Buku
                            </label>
                            <div class="input-group input-group-merge">
                                <textarea
                                    id="abstrak_<?php echo e($jenis_buku->id); ?>"
                                    type="text"
                                    class="form-control <?php $__errorArgs = ['abstrak_<?php echo e($jenis_buku->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="abstrak_<?php echo e($jenis_buku->id); ?>"
                                    placeholder="Enter Your Abstrak"
                                    aria-label="Enter Your Abstrak"
                                    aria-describedby="basic-icon-default-message2"
                                    autofocus
                                ></textarea>
                            </div>
                            <div id="defaultFormControlHelp" class="form-text text-danger">
                                <span class="errorTxt" id="abstrak_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <?php $__currentLoopData = $jenis_buku->file_place; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($field->type == 'pdf'): ?>
                                <div class="col-sm-6 mb-3">
                                    <label for="defaultFormControlInput" class="form-label">
                                        <?php echo e($field->name); ?>

                                    </label>
                                    <?php if($field->note != null): ?>
                                        <div id="defaultFormControlHelp" class="form-text mb-2" style="margin-top:  -3px;">
                                            <span><?php echo e($field->note); ?></span>
                                        </div>
                                    <?php endif; ?>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon11">
                                            <i class="bx bxs-file-pdf"></i>
                                        </span>
                                        <input class="form-control" type="file" id="filepdf_<?php echo e($field->id); ?>_<?php echo e($jenis_buku->id); ?>" name="filepdf_<?php echo e($field->id); ?>_<?php echo e($jenis_buku->id); ?>" />
                                    </div>
                                    <div id="defaultFormControlHelp" class="form-text text-danger">
                                        <span class="errorTxt" id="filepdf_<?php echo e($field->id); ?>_<?php echo e($jenis_buku->id); ?>-errorMsg"></span>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <div class="row justify-content-left mt-2">
                <div class="col-sm-12 d-grid gap-2 mx-auto">
                    <button class="btn btn-primary" type="submit">Submit</button>
                </div>
              </div>
            </form>
          </div>
        </div>
    </div>
    <!-- Basic with Icons -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Dinamically -->

    <!-- AJAX -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>

    <!-- js untuk select2  -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <!-- JS untuk Validation -->
    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.js"></script>
    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/additional-methods.js"></script>
    <script src="<?php echo e(asset('assets/js/validate-buku.js')); ?>"></script>

    <script>
        var x = 0;

        $(document).ready(function () {

            $("#jenis_buku").select2({
                theme: 'bootstrap4',
                placeholder: "Please Select",
            });

            $('#jenis_buku').on('change',function(){
                $(".some").hide();
                var some = $(this).find('option:selected').val();
                $("#some_" + some).show();
                x = 0;

                $(".field_subjek_"+some).remove();
                $(".field_pengarang_"+some).remove();
                $(".field_pembimbing_"+some).remove();

                $('.subjek_wrapper_'+some).append(`
                <div class="field_subjek_${some}">\
                    <div class="row">\
                        <div class="col-10 col-lg-11">\
                            <label for="defaultFormControlInput" class="form-label"> Nama Subjek </label>\
                        </div>\
                    </div>\
                    <div class="row">\
                        <div class="col-10 col-lg-11 mb-3">\
                            <div class="input-group">\
                                <span class="input-group-text" id="basic-addon11">\
                                    <i class="bx bxs-user"></i>\
                                </span>\
                                <input id="subjek_${some}" type="text" class="form-control <?php $__errorArgs = ['subjek_${some}'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="subjek_${some}[]" placeholder="Enter A Subject " aria-describedby="basic-addon13" required autofocus />\
                            </div>\
                            <div id="defaultFormControlHelp" class="form-text text-danger">\
                                <span class="errorTxt" id="subjek_${some}-errorMsg"></span>\
                            </div>\
                        </div>\
                        <div class="col-2 col-lg-1 mb-3 text-end" id="btn_plus">\
                            <a class="btn btn-icon btn-dark add_button_subjek_${some}" id="tombol_plus" data-toggle="tooltip" href="javascript:void(0);" role="button" aria-haspopup="true" aria-expanded="false" style=" width: calc(2.2rem + 2px); height: calc(2.2rem + 2px);" >\
                                <span class="tf-icons bx bx-plus"></span>\
                            </a>\
                        </div>\
                    </div>\
                </div>`);

                $('.pengarang_wrapper_'+some).append(`
                <div class="field_pengarang_${some}">\
                    <div class="row">\
                        <div class="col-12 col-lg-6">\
                            <label for="defaultFormControlInput" class="form-label"> No Identitas / NIM </label>\
                        </div>\
                        <div class="col-10 col-lg-5">\
                            <label for="defaultFormControlInput" class="form-label"> Nama Pengarang </label>\
                        </div>\
                    </div>\
                    <div class="row">\
                        <div class="col-12 col-lg-6 mb-3">\
                            <div class="input-group">\
                                <span class="input-group-text" id="basic-addon11">\
                                    <i class="bx bx-hash"></i>\
                                </span>\
                                <input id="no_pengarang_${some}" type="text" class="form-control <?php $__errorArgs = ['no_pengarang_${some}'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="no_pengarang_${some}[]" placeholder="Enter An ID Author " aria-describedby="basic-addon13" autofocus />\
                            </div>\
                            <div id="defaultFormControlHelp" class="form-text text-danger">\
                                <span class="errorTxt" id="no_pengarang_${some}[]-errorMsg"></span>\
                            </div>\
                        </div>\
                        <div class="col-10 col-lg-5 mb-3">\
                            <div class="input-group">\
                                <span class="input-group-text" id="basic-addon11">\
                                    <i class="bx bxs-user"></i>\
                                </span>\
                                <input id="pengarang_${some}" type="text" class="form-control <?php $__errorArgs = ['pengarang_${some}'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pengarang_${some}[]" placeholder="Enter A Author " aria-describedby="basic-addon13" required autofocus />\
                            </div>\
                            <div id="defaultFormControlHelp" class="form-text text-danger">\
                                <span class="errorTxt" id="pengarang_${some}-errorMsg"></span>\
                            </div>\
                        </div>\
                        <div class="col-2 col-lg-1 mb-3 text-end" id="btn_plus">\
                            <a class="btn btn-icon btn-dark add_button_pengarang_${some}" id="tombol_plus" data-toggle="tooltip" href="javascript:void(0);" role="button" aria-haspopup="true" aria-expanded="false" style=" width: calc(2.2rem + 2px); height: calc(2.2rem + 2px);" >\
                                <span class="tf-icons bx bx-plus"></span>\
                            </a>\
                        </div>\
                    </div>\
                </div>`);

                $('.pembimbing_wrapper_'+some).append(`
                <div class="field_pembimbing_${some}">\
                    <div class="row">\
                        <div class="col-12 col-lg-6">\
                            <label for="defaultFormControlInput" class="form-label"> No Identitas / NIP </label>\
                        </div>\
                        <div class="col-10 col-lg-5">\
                            <label for="defaultFormControlInput" class="form-label"> Nama Pembimbing </label>\
                        </div>\
                    </div>\
                    <div class="row">\
                        <div class="col-12 col-lg-6 mb-3">\
                            <div class="input-group">\
                                <span class="input-group-text" id="basic-addon11">\
                                    <i class="bx bx-hash"></i>\
                                </span>\
                                <input id="no_pembimbing_${some}" type="text" class="form-control <?php $__errorArgs = ['no_pembimbing_${some}'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="no_pembimbing_${some}[]" placeholder="Enter An ID Mentor " aria-describedby="basic-addon13" autofocus />\
                            </div>\
                            <div id="defaultFormControlHelp" class="form-text text-danger">\
                                <span class="errorTxt" id="no_pembimbing_${some}-errorMsg"></span>\
                            </div>\
                        </div>\
                        <div class="col-10 col-lg-5 mb-3">\
                            <div class="input-group">\
                                <span class="input-group-text" id="basic-addon11">\
                                    <i class="bx bxs-user"></i>\
                                </span>\
                                <input id="pembimbing_${some}" type="text" class="form-control <?php $__errorArgs = ['pembimbing_${some}'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pembimbing_${some}[]" placeholder="Enter A Mentor " aria-describedby="basic-addon13" required autofocus />\
                            </div>\
                            <div id="defaultFormControlHelp" class="form-text text-danger">\
                                <span class="errorTxt" id="pembimbing_${some}-errorMsg"></span>\
                            </div>\
                        </div>\
                        <div class="col-2 col-lg-1 mb-3 text-end" id="btn_plus">\
                            <a class="btn btn-icon btn-dark add_button_pembimbing_${some}" id="tombol_plus" data-toggle="tooltip" href="javascript:void(0);" role="button" aria-haspopup="true" aria-expanded="false" style=" width: calc(2.2rem + 2px); height: calc(2.2rem + 2px);" >\
                                <span class="tf-icons bx bx-plus"></span>\
                            </a>\
                        </div>\
                    </div>\
                </div>`);

                $(".wrapper_pengarang_"+some).remove();

                $('#jenis_pengadaan_'+ some).select2({
                    theme: 'bootstrap4',
                    placeholder: "Please Select",
                });

                $('#status_pengadaan_'+ some).select2({
                    theme: 'bootstrap4',
                    placeholder: "Please Select",
                });

                $("#fakultas_"+ some).select2({
                    theme: 'bootstrap4',
                    placeholder: "Please Select",
                });

                $("#prodi_"+ some).select2({
                    theme: 'bootstrap4',
                    placeholder: "Please Select",
                });

                $("#sirkulasi_"+ some).select2({
                    theme: 'bootstrap4',
                    placeholder: "Please Select",
                });

                $("#status_"+ some).select2({
                    theme: 'bootstrap4',
                    placeholder: "Please Select",
                });

                $("#role_download_"+ some).select2({
                    theme: 'bootstrap4',
                    placeholder: "Please Select",
                });

                $('#checkkodebuku_'+ some).click(function(e){
                    const kodebuku = $('#kode_buku_'+ some).val();
                    // alert(kodebuku);

                    $.ajax({
                        url: '/getKodeBuku/'+kodebuku,
                        type: "GET",
                        dataType: "json",
                        success: function(infobuku){
                            if(infobuku.length === 1){
                                e.preventDefault();

                                var form = $(this).closest("form");
                                var name = $(this).data("name");

                                Swal.fire({
                                    title: "Buku Sudah Terdaftar !!",
                                    text: "Apakah Kamu Ingin Menambah Eksemplar ??",
                                    icon: "warning",
                                    showCancelButton: true,
                                    confirmButtonClass: "bg-danger",
                                    confirmButtonText: "Yes, I'am Sure !",
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        window.location.href = "<?php echo e(URL::to('/home')); ?>"
                                    }
                                });
                            } else {
                                $('.toast').addClass("show");
                            }
                        }
                    });
                });

                var maxFieldSubjek = 100;
                var maxFieldPengarang = 100;
                var maxFieldPembimbing = 100;

                $('.add_button_subjek_'+some).on('click', function(e){
                    if(x < maxFieldSubjek){
                        x++;
                        $('.subjek_wrapper_'+some).append(`
                        <div class="wrapper_subjek_${some}" id="wrapper_subjek_${some}">\
                            <div class="row">\
                                <div class="col-10 col-lg-11 mb-3">\
                                    <div class="input-group">\
                                        <span class="input-group-text" id="basic-addon11">\
                                            <i class="bx bxs-user"></i>\
                                        </span>\
                                        <input id="subjek_${some}" type="text" class="form-control <?php $__errorArgs = ['subjek_${some}'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="subjek_${some}[]" placeholder="Enter A Subject " aria-describedby="basic-addon13" required autofocus />\
                                    </div>\
                                    <div id="defaultFormControlHelp" class="form-text text-danger">\
                                        <span class="errorTxt" id="subjek_${some}-errorMsg"></span>\
                                    </div>\
                                </div>\
                                <div class="col-2 col-lg-1 mb-3 text-end" id="btn_remove_${x}">\
                                    <a class="btn btn-icon btn-danger remove_subjek_button" data-toggle="tooltip" href="javascript:void(0);" role="button" aria-haspopup="true" aria-expanded="false" style=" width: calc(2.2rem + 2px); height: calc(2.2rem + 2px);">\
                                        <span class="tf-icons bx bxs-trash"></span>\
                                    </a>\
                                </div>\
                            </div>\
                        </div>`);
                    }
                });

                $('.subjek_wrapper_'+some).on('click', '.remove_subjek_button', function(e){
                    e.preventDefault();
                    $(this).closest("#wrapper_subjek_"+some).remove(); //Remove field html
                });

                $('.add_button_pengarang_'+some).on('click', function(e){
                    if(x < maxFieldPengarang){
                        x++;
                        $('.pengarang_wrapper_'+some).append(`
                        <div class="wrapper_pengarang_${some}" id="wrapper_pengarang_${some}">\
                            <div class="row">\
                                <div class="col-12 col-lg-6 mb-3">\
                                    <div class="input-group">\
                                        <span class="input-group-text" id="basic-addon11">\
                                            <i class="bx bx-hash"></i>\
                                        </span>\
                                        <input id="no_pengarang_${some}" type="text" class="form-control <?php $__errorArgs = ['no_pengarang_${some}'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="no_pengarang_${some}[]" placeholder="Enter An ID Author " aria-describedby="basic-addon13" autofocus />\
                                    </div>\
                                    <div id="defaultFormControlHelp" class="form-text text-danger">\
                                        <span class="errorTxt" id="no_pengarang_${some}-errorMsg"></span>\
                                    </div>\
                                </div>\
                                <div class="col-10 col-lg-5 mb-3">\
                                    <div class="input-group">\
                                        <span class="input-group-text" id="basic-addon11">\
                                            <i class="bx bxs-user"></i>\
                                        </span>\
                                        <input id="pengarang_${some}" type="text" class="form-control <?php $__errorArgs = ['pengarang_${some}'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pengarang_${some}[]" placeholder="Enter A Author " aria-describedby="basic-addon13" required autofocus />\
                                    </div>\
                                    <div id="defaultFormControlHelp" class="form-text text-danger">\
                                        <span class="errorTxt" id="pengarang_${some}-errorMsg"></span>\
                                    </div>\
                                </div>\
                                <div class="col-2 col-lg-1 mb-3 text-end" id="btn_remove_${x}">\
                                    <a class="btn btn-icon btn-danger remove_pengarang_button" data-toggle="tooltip" href="javascript:void(0);" role="button" aria-haspopup="true" aria-expanded="false" style=" width: calc(2.2rem + 2px); height: calc(2.2rem + 2px);">\
                                        <span class="tf-icons bx bxs-trash"></span>\
                                    </a>\
                                </div>\
                            </div>\
                        </div>`);
                    }
                });

                $('.pengarang_wrapper_'+some).on('click', '.remove_pengarang_button', function(e){
                    e.preventDefault();
                    $(this).closest("#wrapper_pengarang_"+some).remove(); //Remove field html
                });

                $('.add_button_pembimbing_'+some).on('click', function(e){
                    if(x < maxFieldPembimbing){
                        x++;
                        $('.pembimbing_wrapper_'+some).append(`
                        <div class="wrapper_pembimbing_${some}" id="wrapper_pembimbing_${some}">\
                            <div class="row">\
                                <div class="col-12 col-lg-6 mb-3">\
                                    <div class="input-group">\
                                        <span class="input-group-text" id="basic-addon11">\
                                            <i class="bx bx-hash"></i>\
                                        </span>\
                                        <input id="no_pembimbing_${some}" type="text" class="form-control <?php $__errorArgs = ['no_pembimbing_${some}'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="no_pembimbing_${some}[]" placeholder="Enter An ID Mentor " aria-describedby="basic-addon13" autofocus />\
                                    </div>\
                                    <div id="defaultFormControlHelp" class="form-text text-danger">\
                                        <span class="errorTxt" id="no_pembimbing_${some}-errorMsg"></span>\
                                    </div>\
                                </div>\
                                <div class="col-10 col-lg-5 mb-3">\
                                    <div class="input-group">\
                                        <span class="input-group-text" id="basic-addon11">\
                                            <i class="bx bxs-user"></i>\
                                        </span>\
                                        <input id="pembimbing_${some}" type="text" class="form-control <?php $__errorArgs = ['pembimbing_${some}'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pembimbing_${some}[]" placeholder="Enter A Mentor " aria-describedby="basic-addon13" required autofocus />\
                                    </div>\
                                    <div id="defaultFormControlHelp" class="form-text text-danger">\
                                        <span class="errorTxt" id="pembimbing_${some}-errorMsg"></span>\
                                    </div>\
                                </div>\
                                <div class="col-2 col-lg-1 mb-3 text-end" id="btn_remove_${x}">\
                                    <a class="btn btn-icon btn-danger remove_pembimbing_button" data-toggle="tooltip" href="javascript:void(0);" role="button" aria-haspopup="true" aria-expanded="false" style=" width: calc(2.2rem + 2px); height: calc(2.2rem + 2px);">\
                                        <span class="tf-icons bx bxs-trash"></span>\
                                    </a>\
                                </div>\
                            </div>\
                        </div>`);
                    }
                });

                $('.pembimbing_wrapper_'+some).on('click', '.remove_pembimbing_button', function(e){
                    e.preventDefault();
                    $(this).closest("#wrapper_pembimbing_"+some).remove(); //Remove field html
                });

                $('.pengarang_'+some).on('change',function(){
                    $(".addpengarang_"+some).hide();
                    $("#style_pengarang").removeClass( "col-12" ).addClass("col-8");
                    $("#btn_plus").removeClass("text-end");
                    var author = $(this).find('option:selected').val();
                    /* console.log(target); */
                    if (author == 'add'){
                        $("#style_pengarang").removeClass( "col-8" ).addClass("col-12");
                        $("#btn_plus").addClass("text-end");
                        $("#addpengarang_"+some).show();
                    };
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\TA\Laravel-8\elit-ittelkomsby\resources\views/admin/akuisisi/index.blade.php ENDPATH**/ ?>