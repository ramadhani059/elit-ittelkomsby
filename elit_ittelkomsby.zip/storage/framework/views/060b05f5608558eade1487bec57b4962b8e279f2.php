<!DOCTYPE html>
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="<?php echo e(asset('assets/')); ?>"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>ELIT ITTelkom Surabaya</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon/favicon.ico')); ?>" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/fonts/boxicons.css')); ?>" />
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!-- Core CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/core.css')); ?>" class="template-customizer-core-css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/theme-default.css')); ?>" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/demo.css')); ?>" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css')); ?>" />
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@ttskch/select2-bootstrap4-theme@x.x.x/dist/select2-bootstrap4.min.css">

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="<?php echo e(asset('assets/vendor/js/helpers.js')); ?>"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="<?php echo e(asset('assets/js/config.js')); ?>"></script>

    <style>
      body{
        background-image: url(<?php echo e(asset('assets/img/backgrounds/DesainLoginWifiYangDIpakai.png')); ?>);
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
        background-attachment: fixed;
        height: 100%;
      }
    </style>

  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">

              <!-- Tabs -->

              <div class="row" style="padding-top: 50px; padding-bottom: 50px;">
                <div class="col-xl-4"></div>
                <div class="col-xl-4">
                  <div class="nav-align-top mb-6">
                    <ul class="nav nav-tabs nav-fill" role="tablist">
                      <li class="nav-item">
                        <button
                          type="button"
                          class="nav-link active"
                          role="tab"
                          data-bs-toggle="tab"
                          data-bs-target="#navs-justified-login"
                          aria-controls="navs-justified-login"
                          aria-selected="true"
                        >
                          Login
                        </button>
                      </li>
                      <li class="nav-item">
                        <button
                          type="button"
                          class="nav-link"
                          role="tab"
                          data-bs-toggle="tab"
                          data-bs-target="#navs-justified-register"
                          aria-controls="navs-justified-register"
                          aria-selected="false"
                        >
                          Register
                        </button>
                      </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="navs-justified-login" role="tabpanel">
                            <form method="POST" action="<?php echo e(route('login')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label for="defaultFormControlInput" class="form-label">
                                        Email
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon11">
                                            <i class="bx bxs-user"></i>
                                        </span>
                                        <input
                                            id="email"
                                            type="email"
                                            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="email"
                                            value="<?php echo e(old('email')); ?>"
                                            placeholder="name@example.com"
                                            aria-describedby="basic-addon13"
                                            required
                                            autocomplete="email"
                                            autofocus
                                        />
                                    </div>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div id="defaultFormControlHelp" class="form-text text-danger">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-password-toggle mb-3">
                                    <label class="form-label" for="basic-default-password12">Password</label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon11">
                                            <i class="bx bxs-lock-alt"></i>
                                        </span>
                                        <input
                                            id="password"
                                            type="password"
                                            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="basic-default-password12"
                                            placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                                            aria-describedby="basic-default-password2"
                                            name="password"
                                            required
                                            autocomplete="current-password"
                                        />
                                        <span id="basic-default-password2" class="input-group-text cursor-pointer">
                                            <i class="bx bx-hide"></i>
                                        </span>
                                    </div>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div id="defaultFormControlHelp" class="form-text text-danger">
                                            Please Enter Your Password
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mt-4">
                                    <div class="d-grid gap-2 col-lg-12 mx-auto">
                                        <button class="btn btn-danger btn-lg" type="submit">Login</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                      <div class="tab-pane fade" id="navs-justified-register" role="tabpanel">
                        <form action="<?php echo e(route('register.store')); ?>" method="POST" enctype="multipart/form-data" id="registerForm">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="defaultFormControlInput" class="form-label">
                                    Nama Lengkap
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text" id="basic-addon11">
                                        <i class="bx bxs-user"></i>
                                    </span>
                                    <input
                                        id="fullname"
                                        type="text"
                                        class="form-control <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="fullname"
                                        placeholder="Your Full Name"
                                        aria-describedby="basic-addon13"
                                        value="<?php echo e(old('fullname')); ?>"
                                        autocomplete="fullname"
                                    />
                                </div>
                                <div id="defaultFormControlHelp" class="form-text text-danger">
                                    <span class="errorTxt" id="fullname-errorMsg"></span>
                                </div>
                            </div>
                            <div class="form-password-toggle mb-3">
                                <label class="form-label" for="basic-default-password12">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text" id="basic-addon11">
                                        <i class="bx bxs-lock-alt"></i>
                                    </span>
                                    <input
                                        id="bxs-lock-alt"
                                        type="password"
                                        class="form-control <?php $__errorArgs = ['password_register'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                                        aria-describedby="basic-default-password2"
                                        name="password_register"
                                        value="<?php echo e(old('password_register')); ?>"
                                        autocomplete="current-password"
                                    />
                                    <span id="basic-default-password2" class="input-group-text cursor-pointer">
                                        <i class="bx bx-hide"></i>
                                    </span>
                                </div>
                                <div id="defaultFormControlHelp" class="form-text text-danger">
                                    <span class="errorTxt" id="password_register-errorMsg"></span>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="defaultFormControlInput" class="form-label">
                                    Email
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text" id="basic-addon11">
                                        <i class="bx bx-at"></i>
                                    </span>
                                    <input
                                        id="email"
                                        type="email"
                                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="email"
                                        placeholder="name@example.com"
                                        aria-describedby="basic-addon13"
                                        autocomplete="email"
                                    />
                                </div>
                                <div id="defaultFormControlHelp" class="form-text text-danger">
                                    <span class="errorTxt" id="email-errorMsg"></span>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="defaultFormControlInput" class="form-label">
                                    Nomor Handphone
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text" id="basic-addon11">
                                        <i class="bx bxs-phone"></i>
                                    </span>
                                    <input
                                        id="telp"
                                        type="tel"
                                        class="form-control <?php $__errorArgs = ['telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="telp"
                                        placeholder="08xxxxxxxxxx"
                                        aria-describedby="basic-addon13"
                                        value="<?php echo e(old('telp')); ?>"
                                        autocomplete="tel-national"
                                    />
                                </div>
                                <div id="defaultFormControlHelp" class="form-text text-danger">
                                    <span class="errorTxt" id="telp-errorMsg"></span>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="defaultFormControlInput" class="form-label">
                                    Alamat
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text" id="basic-addon11">
                                        <i class="bx bxs-home"></i>
                                    </span>
                                    <input
                                        id="address"
                                        type="text"
                                        class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="address"
                                        placeholder="Your Address"
                                        aria-describedby="basic-addon13"
                                        value="<?php echo e(old('address')); ?>"
                                        autocomplete="address-line1"
                                    />
                                </div>
                                <div id="defaultFormControlHelp" class="form-text text-danger">
                                    <span class="errorTxt" id="address-errorMsg"></span>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="defaultFormControlInput" class="form-label">
                                    Jenis Keanggotaan
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text" id="basic-addon11">
                                        <i class="bx bxs-user"></i>
                                    </span>
                                    <select class="form-select jenisanggota <?php $__errorArgs = ['jenisanggota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jenisanggota" name="jenisanggota">
                                        <option value=""></option>
                                        <?php $__currentLoopData = $jenis_keanggotaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenisanggota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($jenisanggota->id); ?>"><?php echo e($jenisanggota->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div id="defaultFormControlHelp" class="form-text text-danger">
                                    <span class="errorTxt" id="jenisanggota-errorMsg"></span>
                                </div>
                            </div>
                            <?php $__currentLoopData = $jenis_keanggotaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenisanggota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="some" id="some_<?php echo e($jenisanggota->id); ?>" style="display: none;">
                                    <?php if($jenisanggota->role_institusi == 1): ?>
                                        <div class="mb-3">
                                            <label for="defaultFormControlInput" class="form-label">
                                                Nama Institusi
                                            </label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon11">
                                                    <i class="bx bxs-buildings"></i>
                                                </span>
                                                <select class="form-select namainstitusi <?php $__errorArgs = ['namainstitusi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="namainstitusi_<?php echo e($jenisanggota->id); ?>" name="namainstitusi_<?php echo e($jenisanggota->id); ?>">
                                                    <option value=""></option>

                                                </select>
                                            </div>
                                            <div id="defaultFormControlHelp" class="form-text text-danger">
                                                <span class="errorTxt" id="namainstitusi_<?php echo e($jenisanggota->id); ?>-errorMsg"></span>
                                            </div>
                                        </div>
                                        <div class="addinstitusi" id="addinstitusi" style="display: none;">
                                            <div class="mb-3">
                                                <label for="defaultFormControlInput" class="form-label">
                                                    Tambah Nama Institusi
                                                </label>
                                                <div class="input-group">
                                                    <span class="input-group-text" id="basic-addon11">
                                                        <i class="bx bxs-buildings"></i>
                                                    </span>
                                                    <input
                                                        id="tambahinstitusi_<?php echo e($jenisanggota->id); ?>"
                                                        type="text"
                                                        class="form-control <?php $__errorArgs = ['tambahinstitusi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="tambahinstitusi_<?php echo e($jenisanggota->id); ?>"
                                                        placeholder="Add Your Institution"
                                                        aria-describedby="basic-addon13"
                                                    />
                                                </div>
                                                <div id="defaultFormControlHelp" class="form-text text-danger">
                                                    <span class="errorTxt" id="tambahinstitusi_<?php echo e($jenisanggota->id); ?>-errorMsg"></span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($jenisanggota->role_user == 1): ?>
                                        <div class="mb-3">
                                            <label for="defaultFormControlInput" class="form-label">
                                                Fakultas
                                            </label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon11">
                                                    <i class="bx bxs-graduation"></i>
                                                </span>
                                                <select class="form-select fakultas <?php $__errorArgs = ['jenisanggota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="fakultas_<?php echo e($jenisanggota->id); ?>" name="fakultas_<?php echo e($jenisanggota->id); ?>">
                                                    <option value=""></option>
                                                </select>
                                            </div>
                                            <div id="defaultFormControlHelp" class="form-text text-danger">
                                                <span class="errorTxt" id="fakultas_<?php echo e($jenisanggota->id); ?>-errorMsg"></span>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="defaultFormControlInput" class="form-label">
                                                Program Studi
                                            </label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon11">
                                                    <i class="bx bxs-graduation"></i>
                                                </span>
                                                <select class="form-select jurusan <?php $__errorArgs = ['jenisanggota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jurusan_<?php echo e($jenisanggota->id); ?>" name="jurusan_<?php echo e($jenisanggota->id); ?>">
                                                    <option value=""></option>
                                                </select>
                                            </div>
                                            <div id="defaultFormControlHelp" class="form-text text-danger">
                                                <span class="errorTxt" id="jurusan_<?php echo e($jenisanggota->id); ?>-errorMsg"></span>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($jenisanggota->role_ktp == 1): ?>
                                        <div class="mb-3">
                                            <label for="defaultFormControlInput" class="form-label">
                                                KTP
                                            </label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon11">
                                                    <i class="bx bxs-id-card"></i>
                                                </span>
                                                <input class="form-control" type="file" id="filektp_<?php echo e($jenisanggota->id); ?>" name="filektp_<?php echo e($jenisanggota->id); ?>" />
                                            </div>
                                            <div id="defaultFormControlHelp" class="form-text text-danger">
                                                <span class="errorTxt" id="filektp_<?php echo e($jenisanggota->id); ?>-errorMsg"></span>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($jenisanggota->role_karpeg_ktm == 1): ?>
                                        <div class="mb-3">
                                            <label for="defaultFormControlInput" class="form-label">
                                                Karpeg/KTM
                                            </label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon11">
                                                    <i class="bx bxs-id-card"></i>
                                                </span>
                                                <input class="form-control" type="file" id="filekarpegktm_<?php echo e($jenisanggota->id); ?>" name="filekarpegktm_<?php echo e($jenisanggota->id); ?>" />
                                            </div>
                                            <div id="defaultFormControlHelp" class="form-text text-danger">
                                                <span class="errorTxt" id="filekarpegktm_<?php echo e($jenisanggota->id); ?>-errorMsg"></span>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($jenisanggota->role_ijazah == 1): ?>
                                        <div class="mb-3">
                                            <label for="defaultFormControlInput" class="form-label">
                                                Ijazah
                                            </label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon11">
                                                    <i class="bx bxs-file"></i>
                                                </span>
                                                <input class="form-control" type="file" id="fileijazah_<?php echo e($jenisanggota->id); ?>" name="fileijazah_<?php echo e($jenisanggota->id); ?>" />
                                            </div>
                                            <div id="defaultFormControlHelp" class="form-text text-danger">
                                                <span class="errorTxt" id="fileijazah_<?php echo e($jenisanggota->id); ?>-errorMsg"></span>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="mt-4">
                                <div class="d-grid gap-2 col-lg-12 mx-auto">
                                    <button class="btn btn-danger btn-lg" type="submit">Register</button>
                                </div>
                            </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-4"></div>
              </div>
              <!-- Tabs -->

            </div>
            <!-- / Content -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="<?php echo e(asset('assets/vendor/libs/jquery/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/popper/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/vendor/js/menu.js')); ?>"></script>

    <!-- AJAX -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>

    <!-- js untuk select2  -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <!-- JS untuk Validation -->
    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.js"></script>
    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/additional-methods.js"></script>
    <script src="<?php echo e(asset('assets/js/validate.js')); ?>"></script>

    <!-- Dropdown -->
    <script>
        $(document).ready(function () {

            $("#jenisanggota").select2({
                theme: 'bootstrap4',
                placeholder: "Please Select",
            });

            $('#jenisanggota').on('change',function(){
                $(".some").hide();
                var some = $(this).find('option:selected').val();
                /* console.log(some); */
                $("#some_" + some).show();

                $("#namainstitusi_" + some).show().select2({
                    theme: 'bootstrap4',
                    placeholder: "Please Select",
                });

                $("#fakultas_" + some).select2({
                    theme: 'bootstrap4',
                    placeholder: "Please Select",
                });

                $("#jurusan_" + some).select2({
                    theme: 'bootstrap4',
                    placeholder: "Please Select",
                });

                $.ajax({
                    url: '/getJenisAnggota/'+some,
                    type: "GET",
                    dataType: "json",
                    success: function(anggota){
                        $.ajax({
                            url: '/getInstitusi/'+some,
                            type: "GET",
                            dataType: "json",
                            success: function(data){
                                $('select[name="namainstitusi_'+ some +'"]').empty();
                                $('select[name="namainstitusi_'+ some +'"]').append('<option value="">Please Select</option>');
                                $.each(anggota, function(index, nama){
                                    if(nama.role_add_institusi){
                                        $('select[name="namainstitusi_'+ some +'"]').append('<option value="add">Add Your Institution</option>');
                                    }
                                })
                                $.each(data, function(key, value){
                                    $('select[name="namainstitusi_'+ some +'"]').append('<option value="'+ value.id +'">'+ value.nama +'</option>');
                                });
                            }
                        });
                    }
                });

                $.ajax({
                    url: '/getFakultas/',
                    type: "GET",
                    dataType: "json",
                    success: function(data){
                        $('select[name="fakultas_'+ some +'"]').empty();
                        $('select[name="fakultas_'+ some +'"]').append('<option value="">Please Select</option>');
                        $.each(data, function(key, value){
                            $('select[name="fakultas_'+ some +'"]').append('<option value="'+ value.kode_fakultas +'">'+ value.nama +'</option>');
                        });
                    }
                });

                $.ajax({
                    url: '/getProdi/',
                    type: "GET",
                    dataType: "json",
                    success: function(data){
                        $('select[name="jurusan_'+ some +'"]').empty();
                        $('select[name="jurusan_'+ some +'"]').append('<option value="">Please Select</option>');
                        $.each(data, function(key, value){
                            $('select[name="jurusan_'+ some +'"]').append('<option value="'+ value.nama +'">'+ value.nama +'</option>');
                        });
                    }
                });
            });

            $('.namainstitusi').on('change',function(){
                $(".addinstitusi").hide();
                var target = $(this).find('option:selected').val();
                /* console.log(target); */
                if (target == 'add'){
                    $("#addinstitusi").show();
                };
            });
        });
    </script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>
<?php /**PATH D:\Kuliah\TA\Laravel-8\elit-ittelkomsby\resources\views/auth/login.blade.php ENDPATH**/ ?>