<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('m__prodis', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('id_fakultas');
            $table->string('kode_prodi');
            $table->string('nama');
            $table->timestamps();

            $table->foreign('id_fakultas')->references('id')->on('m__fakultas');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('m__prodis');
    }
};
